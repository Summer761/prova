function inicio() {
    window.alert(`olá, Mundo!`)
}
function butao() {
    window.alert(`Você clicou no botão!`)
}
function asa() {
    let nome = window.prompt('Qual é o seu nome')
    window.alert(`olá, ${nome} é um prazer ver voce aqui !`)
}
function voar() {
    let n1 = window.prompt('Digite seu nome:')

    let res = document.querySelector('section#res')
    res.innerHTML = `<span>Olá, ${n1}! É um grande prazer te conhecer! 🖖<\span>`
}
function vaar() {
    let n1 = Number(window.prompt('Digite um número:'))

    let res1 = document.querySelector('section#res1')
    res1.innerHTML = `<span> O dobro é ${n1*2} e a matade é igual a ${n1/2}<\span>`
}
function aaa() {
    let n1 = Number(window.prompt('Digite um número:'))
    let n2 = Number(window.prompt('Digite outro número:'))

    let res2 = document.querySelector('section#res2')
    res2.innerHTML = `<span> A soma entre ${n1} e ${n2} é igual a ${n1+n2}<\span>`
}
function aa() {
    let nome = window.prompt("Qual o seu nome?")
    let n9 = Number(window.prompt('Digite a primeira nota:'))
    let n10 = Number(window.prompt('Digite a segunda nota:'))

    med = (n9 + n10) / 2

    let res3 = document.querySelector('section#res3')
    res3.innerHTML = `Olá, ${nome}. Sua média foi ${med}`
    
}
function eles() {
    let nome = window.prompt("Qual o seu nome?")
    let n22 = Number(window.prompt('Digite a primeira nota:'))
    let n23 = Number(window.prompt('Digite a segunda nota:'))

    med = (n22 + n23) / 2

    let res4 = document.querySelector('section#res4')
    res4.innerHTML = `Olá, ${nome}. Sua média foi ${med}, Parabens!`
}
function calcular(){
    let num = Number(window.prompt('Digite um numero: '));
    let res = document.querySelector('section#result');
    res.innerHTML = `<p>O numero a ser analisado aqui sera o <strong>${num}</strong></p>`
    res.innerHTML += `<p>O seu valor absoluto é ${Math.abs(num)}</p>`
    res.innerHTML += `<p>A sua parte inteira é ${Math.trunc(num)}</p>`
    res.innerHTML += `<p>O seu valor inteiro mais proximo é ${Math.round(num)}</p>`
    res.innerHTML += `<p>A sua raiz quadrada é${Math.sqrt(num)}</p>`
    res.innerHTML += `<p>A sua raiz cubica é${Math.cbrt(num)}</p>`
    res.innerHTML += `<p>O valor de ${num} <sup>2</sup> é ${math.pow(num, 2)}</p>`
    res.innerHTML += `<p>O valor de ${num} <sup>3</sup> é ${math.pow(num, 3)}</p>`

}
function contar(){
    contador++;
    res.innerHTML = `<p>${contador}</p>`;
}
function zerar(){
    contador = 0;
    res.innerHTML = null;
}
let contador=0;
let res = document.querySelector('result');

var resultado = window.document.getElementById('result')

function Acao1() {
    resultado.innerHTML += `<p>Clicou no primeiro botão</p>` 
}

function Acao2() {
    resultado.innerHTML += `<p>Clicou no segundo botão</p>` 
}

function inicio() {
    window.alert(`olá, Mundo!`)
}